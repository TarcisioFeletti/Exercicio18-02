/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pss.aprovacao;

/**
 *
 * @author tarci
 */
public class DiretorGeral {
    private String nome;
    Encaminhamento encaminhamento;
    
    DiretorGeral(String nome, Encaminhamento enc) {
        this.nome = nome;
        this.encaminhamento = enc;
    }
    
    public boolean aprovar(Encaminhamento encaminhamento){
        if(encaminhamento.pedido.getValor()<= 15000.00){
            return true;
        }else
            return false;
    }
}
