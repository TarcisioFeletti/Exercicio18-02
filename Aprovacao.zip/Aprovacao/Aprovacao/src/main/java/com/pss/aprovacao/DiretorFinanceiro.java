/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pss.aprovacao;

/**
 *
 * @author tarci
 */
public class DiretorFinanceiro {
    private String nome;
    Encaminhamento encaminhamento;

    DiretorFinanceiro(String nome, Encaminhamento enc) {
        this.nome = nome;
        this.encaminhamento = enc;
    }
    
    public boolean aprovar(Encaminhamento encaminhamento){
        if(encaminhamento.pedido.getValor()<= 5000.00){
            return true;
        }else
            return false;
    }
    
    public void encaminhar(DiretorGeral superior, Encaminhamento encaminhamento){
        superior.encaminhamento.pedido.setValor(encaminhamento.pedido.getValor());
        superior.encaminhamento.funcionario.setNome(encaminhamento.funcionario.getNome());
    }
}
