/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pss.aprovacao;

/**
 *
 * @author tarci
 */
public class Encaminhamento {
    Funcionario funcionario = new Funcionario();
    PedidoParaAprovacao pedido = new PedidoParaAprovacao();
    
    Encaminhamento(double valor, String superior){
        this.pedido.setValor(valor);
        this.funcionario.setSuperiorHierarquico(superior);
    }
    
}
