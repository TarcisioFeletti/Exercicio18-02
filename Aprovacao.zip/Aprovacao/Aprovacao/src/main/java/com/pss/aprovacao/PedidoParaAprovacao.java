/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pss.aprovacao;

/**
 *
 * @author tarci
 */
public class PedidoParaAprovacao {
    private double valor;
    private boolean aprovado;

    public double getValor() {
        return valor;
    }

    public boolean isAprovado() {
        return aprovado;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public void setAprovado(boolean aprovado) {
        this.aprovado = aprovado;
    }
    
    
    
}
