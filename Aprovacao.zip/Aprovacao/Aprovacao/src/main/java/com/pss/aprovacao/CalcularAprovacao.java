/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pss.aprovacao;

/**
 *
 * @author tarci
 */
public class CalcularAprovacao {
    public static void calcular(Encaminhamento enc){
        GerenteImediato gi = new GerenteImediato("Adair", enc);
        GerenteGeral gg = new GerenteGeral("Rogério", enc);
        DiretorFinanceiro df = new DiretorFinanceiro("Paulo", enc);
        DiretorGeral dg = new DiretorGeral("Rodrigo", enc);
        
        enc.funcionario.setNome("João");
        
        enc.pedido.setAprovado(false);
        
        if(enc.funcionario.getSuperiorHierarquico().equalsIgnoreCase("gerenteimediato")){
            enc.pedido.setAprovado(gi.aprovar(enc));
            if(!enc.pedido.isAprovado()){
                gi.encaminhar(gg, enc);
                enc.pedido.setAprovado(gg.aprovar(enc));
            }
        }else if(enc.funcionario.getSuperiorHierarquico().equalsIgnoreCase("gerentegeral")){
            enc.pedido.setAprovado(gg.aprovar(enc));
            if(!enc.pedido.isAprovado()){
                gg.encaminhar(df, enc);
                enc.pedido.setAprovado(df.aprovar(enc));
            }
        }else if(enc.funcionario.getSuperiorHierarquico().equalsIgnoreCase("diretorfinanceiro")){
            enc.pedido.setAprovado(df.aprovar(enc));
            if(!enc.pedido.isAprovado()){
                df.encaminhar(dg, enc);
                enc.pedido.setAprovado(dg.aprovar(enc));
            }
        }else{
            enc.pedido.setAprovado(dg.aprovar(enc));
        }
        if(enc.pedido.isAprovado()){
            System.out.println("O pedido para aprovação de "+enc.funcionario.getNome()+" foi aprovado");
        }else{
            System.out.println("O pedido para aprovação de "+enc.funcionario.getNome()+" não foi aprovado");
        }
    }
}
