/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pss.aprovacao;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author tarci
 */
public class AprovacaoTest {
    
    public AprovacaoTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void CT001() throws Exception {
        Encaminhamento enc = new Encaminhamento(2500.00,"GerenteImediato");
        boolean teste = false;
        CalcularAprovacao.calcular(enc);
        assertEquals(teste, enc.pedido.isAprovado());
    }
    @Test
    public void CT002() throws Exception {
        Encaminhamento enc = new Encaminhamento(2500.00,"GerenteGeral");
        boolean teste = true;
        CalcularAprovacao.calcular(enc);
        assertEquals(teste, enc.pedido.isAprovado());
    }
    @Test
    public void CT003() throws Exception {
        Encaminhamento enc = new Encaminhamento(500.00,"GerenteImediato");
        boolean teste = true;
        CalcularAprovacao.calcular(enc);
        assertEquals(teste, enc.pedido.isAprovado());
    }
    @Test
    public void CT004() throws Exception {
        Encaminhamento enc = new Encaminhamento(15500.00,"DiretorGeral");
        boolean teste = false;
        CalcularAprovacao.calcular(enc);
        assertEquals(teste, enc.pedido.isAprovado());
    }
    @Test
    public void CT005() throws Exception {
        Encaminhamento enc = new Encaminhamento(4500.00,"DiretorFinanceiro");
        boolean teste = true;
        CalcularAprovacao.calcular(enc);
        assertEquals(teste, enc.pedido.isAprovado());
    }
    @Test
    public void CT006() throws Exception {
        Encaminhamento enc = new Encaminhamento(1500.01,"GerenteImediato");
        boolean teste = false;
        CalcularAprovacao.calcular(enc);
        assertEquals(teste, enc.pedido.isAprovado());
    }
    @Test
    public void CT007() throws Exception {
        Encaminhamento enc = new Encaminhamento(11500.00,"DiretorFinanceiro");
        boolean teste = true;
        CalcularAprovacao.calcular(enc);
        assertEquals(teste, enc.pedido.isAprovado());
    }
    @Test
    public void CT008() throws Exception {
        Encaminhamento enc = new Encaminhamento(7500.00,"GerenteGeral");
        boolean teste = false;
        CalcularAprovacao.calcular(enc);
        assertEquals(teste, enc.pedido.isAprovado());
    }
    @Test
    public void CT009() throws Exception {
        Encaminhamento enc = new Encaminhamento(5000.00,"GerenteImediato");
        boolean teste = false;
        CalcularAprovacao.calcular(enc);
        assertEquals(teste, enc.pedido.isAprovado());
    }
    @Test
    public void CT010() throws Exception {
        Encaminhamento enc = new Encaminhamento(5000.00,"DiretorGeral");
        boolean teste = true;
        CalcularAprovacao.calcular(enc);
        assertEquals(teste, enc.pedido.isAprovado());
    }
}
